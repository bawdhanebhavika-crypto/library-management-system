const books = [
 {id:1,title:'Introduction to Computers',author:'Peter Norton',category:'Technology',quantity:3,available:2},
 {id:2,title:'A Brief History of Time',author:'Stephen Hawking',category:'Science',quantity:2,available:2},
 {id:3,title:'The Alchemist',author:'Paulo Coelho',category:'Fiction',quantity:4,available:3},
 {id:4,title:'Basic Civil Engineering',author:'S. S. Bhavikatti',category:'Engineering',quantity:2,available:1},
 {id:5,title:'Wings of Fire',author:'A. P. J. Abdul Kalam',category:'History',quantity:3,available:3}
];
const students = [
 {name:'Aarav Sharma',id:'STU101'}, {name:'Diya Patel',id:'STU102'},
 {name:'Rohan Mehta',id:'STU103'}, {name:'Ananya Shah',id:'STU104'}
];
let loans = [
 {id:1,student:'STU101',book:1,due:dateOffset(7)},
 {id:2,student:'STU103',book:4,due:dateOffset(4)}
];
let nextBookId = 6, nextLoanId = 3;
function dateOffset(days){const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)}
function bookById(id){return books.find(b=>b.id===Number(id))}
function studentById(id){return students.find(s=>s.id===id)}
function updateStats(){
 document.getElementById('totalBooks').textContent=books.reduce((n,b)=>n+b.quantity,0);
 document.getElementById('availableBooks').textContent=books.reduce((n,b)=>n+b.available,0);
 document.getElementById('issuedBooks').textContent=loans.length;
 document.getElementById('studentCount').textContent=students.length;
}
function renderBooks(){
 const q=document.getElementById('bookSearch').value.toLowerCase();
 const category=document.getElementById('categoryFilter').value;
 const rows=document.getElementById('bookRows');rows.innerHTML='';
 const filtered=books.filter(b=>(category==='all'||b.category===category)&&[b.title,b.author,b.category].join(' ').toLowerCase().includes(q));
 if(!filtered.length){rows.innerHTML='<tr><td colspan="6">No books found. Try another search.</td></tr>';return}
 filtered.forEach(b=>{
  const tr=document.createElement('tr');
  const status=b.available>0?'<span class="pill">Available</span>':'<span class="pill out">All issued</span>';
  tr.innerHTML=`<td>${escapeHtml(b.title)}</td><td>${escapeHtml(b.author)}</td><td>${escapeHtml(b.category)}</td><td>${b.quantity}</td><td>${b.available}</td><td>${status}</td>`;
  rows.appendChild(tr);
 });
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderStudents(){
 const grid=document.getElementById('studentGrid');grid.innerHTML='';
 students.forEach(s=>{const card=document.createElement('div');card.className='student-card';card.innerHTML=`<div class="student-avatar">${escapeHtml(s.name.split(' ').map(w=>w[0]).join('').slice(0,2))}</div><div><strong>${escapeHtml(s.name)}</strong><small>${escapeHtml(s.id)}</small></div>`;grid.appendChild(card)});
 const select=document.getElementById('issueStudent');select.innerHTML='';
 students.forEach(s=>{const o=document.createElement('option');o.value=s.id;o.textContent=`${s.name} (${s.id})`;select.appendChild(o)});
}
function renderIssueBooks(){
 const select=document.getElementById('issueBook');select.innerHTML='';
 books.filter(b=>b.available>0).forEach(b=>{const o=document.createElement('option');o.value=b.id;o.textContent=`${b.title} (${b.available} available)`;select.appendChild(o)});
 if(!select.options.length){const o=document.createElement('option');o.textContent='No books currently available';o.disabled=true;select.appendChild(o)}
}
function renderLoans(){
 const list=document.getElementById('loanList');list.innerHTML='';
 if(!loans.length){list.textContent='No books are currently issued.';return}
 loans.forEach(loan=>{
  const s=studentById(loan.student),b=bookById(loan.book);
  const item=document.createElement('div');item.className='loan-item';
  item.innerHTML=`<div><strong>${escapeHtml(b?b.title:'Unknown book')}</strong><small>${escapeHtml(s?s.name:loan.student)} · Due ${loan.due}</small></div><button class="return-btn" data-return="${loan.id}">Return</button>`;
  list.appendChild(item);
 });
 list.querySelectorAll('[data-return]').forEach(btn=>btn.addEventListener('click',()=>returnBook(Number(btn.dataset.return))));
}
function refresh(){updateStats();renderBooks();renderStudents();renderIssueBooks();renderLoans()}
document.getElementById('bookSearch').addEventListener('input',renderBooks);
document.getElementById('categoryFilter').addEventListener('change',renderBooks);
document.getElementById('dueDate').value=dateOffset(14);
document.getElementById('issueForm').addEventListener('submit',e=>{
 e.preventDefault();
 const student=document.getElementById('issueStudent').value;
 const book=bookById(document.getElementById('issueBook').value);
 const due=document.getElementById('dueDate').value;
 const msg=document.getElementById('issueMessage');
 if(!book||book.available<1){msg.textContent='This book is not available right now.';return}
 if(!due){msg.textContent='Please select a due date.';return}
 book.available--;loans.push({id:nextLoanId++,student,book:book.id,due});
 msg.textContent=`"${book.title}" issued successfully to ${studentById(student).name}.`;
 refresh();
});
function returnBook(id){
 const index=loans.findIndex(l=>l.id===id);if(index<0)return;
 const loan=loans[index],book=bookById(loan.book);if(book)book.available=Math.min(book.quantity,book.available+1);
 loans.splice(index,1);refresh();
}
const bookDialog=document.getElementById('bookDialog'),studentDialog=document.getElementById('studentDialog');
document.getElementById('openAddBook').addEventListener('click',()=>bookDialog.showModal());
document.getElementById('openAddStudent').addEventListener('click',()=>studentDialog.showModal());
document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>document.getElementById(btn.dataset.close).close()));
document.getElementById('addBookForm').addEventListener('submit',e=>{
 e.preventDefault();
 const quantity=Number(document.getElementById('newQuantity').value);
 books.push({id:nextBookId++,title:document.getElementById('newTitle').value.trim(),author:document.getElementById('newAuthor').value.trim(),category:document.getElementById('newCategory').value,quantity,available:quantity});
 bookDialog.close();e.target.reset();document.getElementById('newQuantity').value=1;refresh();
});
document.getElementById('addStudentForm').addEventListener('submit',e=>{
 e.preventDefault();
 const name=document.getElementById('newStudentName').value.trim(),id=document.getElementById('newStudentId').value.trim().toUpperCase();
 if(students.some(s=>s.id.toLowerCase()===id.toLowerCase())){alert('That student ID already exists. Please use a different ID.');return}
 students.push({name,id});studentDialog.close();e.target.reset();refresh();
});
refresh();